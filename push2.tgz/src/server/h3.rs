//! HTTP/3 (QUIC) via quinn + h3-quinn.
//!
//! Crypto: BoringSSL QUIC via `quinn_boring` only (no rustls fallback).
//! TCP TLS remains BoringSSL-primary. `peer_identity` returns peer DER chain (no `todo!`).
//! Request routing mirrors h1/h2：telemetry → ip_access → rate_limit → basic_auth →
//! admin（完整 API）→ page_rules（含 pass_upstream）→ apps → static（§16.1 分发顺序）。

use crate::config::ListenerConfig;
use crate::server::live_config::LiveConfig;
use anyhow::Result;
use std::net::SocketAddr;
use std::sync::Arc;

#[cfg(feature = "tls")]
mod imp {
    use super::*;
    use bytes::Buf;
    use crate::server::apps;
    use crate::server::h1::{BoxBody, REQUEST_BODY_CAP};
    use crate::server::static_files;
    use anyhow::Context;
    use bytes::Bytes;
    use http::{Request, Response, StatusCode};
    use http_body_util::{BodyExt, Full};
    use quinn::{Endpoint, ServerConfig};
    use quinn_boring::server_crypto::BoringQuicServerCrypto;
    use rustls::pki_types::CertificateDer; // peer_identity downcast only

    /// Serve HTTP/3 on UDP `bind` using listener TLS material and static root.
    pub async fn serve(
        bind: SocketAddr,
        lc: ListenerConfig,
        live: Arc<LiveConfig>,
    ) -> Result<()> {
        let ssl = lc.ssl.as_ref().context("h3 listener requires ssl config")?;
        let cert_pem = crate::server::ssl_material::load_bytes(
            ssl.cert.as_deref().context("ssl.cert")?,
        )?;
        let key_pem = crate::server::ssl_material::load_bytes(
            ssl.key.as_deref().context("ssl.key")?,
        )?;

        log::info!("{}", BoringQuicServerCrypto::status_line());

        let server_config = build_server_config(&cert_pem, &key_pem)?;
        // Bind UDP then attach Boring-aware EndpointConfig (HMAC/versions).
        let socket = std::net::UdpSocket::bind(bind).context("h3 udp bind")?;
        let endpoint = Endpoint::new(
            quinn_boring::helpers::default_endpoint_config(),
            Some(server_config),
            socket,
            std::sync::Arc::new(quinn::TokioRuntime),
        )
        .context("h3 quinn endpoint")?;
        log::info!("h3 quinn endpoint ready on {bind} (boring crypto preferred)");

        let leaf_chain = cert_pem;

        while let Some(incoming) = endpoint.accept().await {
            let live_c = Arc::clone(&live);
            let lc_c = lc.clone();
            let leaf = leaf_chain.clone();
            tokio::spawn(async move {
                if let Err(e) = handle_incoming(incoming, live_c, lc_c, leaf).await {
                    log::warn!("h3 connection: {e:#}");
                }
            });
        }
        Ok(())
    }

    /// BoringSSL QUIC only — no silent rustls fallback (spec: H3 crypto = Boring).
    fn build_server_config(cert_pem: &[u8], key_pem: &[u8]) -> Result<ServerConfig> {
        let boring = BoringQuicServerCrypto::try_build(cert_pem, key_pem).ok_or_else(|| {
            anyhow::anyhow!("h3: Boring QUIC try_build failed (invalid PEM or provider)")
        })?;
        log::info!("h3: {}", boring.status_line());
        let crypto = boring.as_quinn_crypto().ok_or_else(|| {
            anyhow::anyhow!("h3: BoringQuicConfig built but as_quinn_crypto=None")
        })?;
        quinn_boring::helpers::server_config(crypto)
            .map_err(|e| anyhow::anyhow!("h3 boring server_config: {e}"))
    }

    async fn handle_incoming(
        incoming: quinn::Incoming,
        live: Arc<LiveConfig>,
        lc: ListenerConfig,
        leaf_der: Vec<u8>,
    ) -> Result<()> {
        let connection = match incoming.await {
            Ok(c) => c,
            Err(e) => {
                // Client abandon / reset during QUIC handshake — never escalate.
                log::debug!("h3 quic handshake soft-fail: {e:#}");
                return Ok(());
            }
        };
        let peer = connection.remote_address();

        let identity = identity_from_connection(&connection, &leaf_der);
        if let Some(leaf) = identity.first() {
            log::debug!(
                "h3 peer_identity leaf_der_len={} chain_len={} peer={peer}",
                leaf.der.len(),
                identity.len()
            );
        }

        // `::h3` / `::h3_quinn` — avoid clashing with this module name `server::h3`.
        let h3_conn = ::h3_quinn::Connection::new(connection);
        let mut server = match ::h3::server::Connection::new(h3_conn).await {
            Ok(s) => s,
            Err(e) => {
                // Handshake / GOAWAY / reset during setup — log and drop connection.
                log::warn!("h3 server connection peer={peer}: {e:#}");
                return Ok(());
            }
        };

        // Stream resets / CANCEL must not tear down the process or the accept loop
        // for the whole endpoint — only this QUIC connection's request loop.
        loop {
            match server.accept().await {
                Ok(Some(resolver)) => {
                    let live_c = Arc::clone(&live);
                    let lc_c = lc.clone();
                    tokio::spawn(async move {
                        if let Err(e) = handle_resolver(resolver, live_c, lc_c, peer).await {
                            // Client reset, idle timeout, or cancel — common; keep serving.
                            log::debug!("h3 request soft-fail peer={peer}: {e:#}");
                        }
                    });
                }
                Ok(None) => break, // connection closed cleanly
                Err(e) => {
                    let msg = format!("{e:#}");
                    let soft = msg.contains("reset")
                        || msg.contains("Reset")
                        || msg.contains("cancel")
                        || msg.contains("Cancel")
                        || msg.contains("closed")
                        || msg.contains("timeout")
                        || msg.contains("Timeout")
                        || msg.contains("GOAWAY")
                        || msg.contains("ApplicationClosed");
                    if soft {
                        log::info!("h3 stream/connection soft-error peer={peer}: {msg}");
                        // After a connection-level error, stop accepting on this conn.
                        break;
                    }
                    log::warn!("h3 accept error peer={peer}: {msg}");
                    break;
                }
            }
        }
        Ok(())
    }

    fn identity_from_connection(
        connection: &quinn::Connection,
        fallback_pem_or_der: &[u8],
    ) -> Vec<quinn_boring::X509> {
        if let Some(any) = connection.peer_identity() {
            if let Some(certs) = any.downcast_ref::<Vec<CertificateDer<'static>>>() {
                let chain =
                    quinn_boring::peer_identity_from_ders(certs.iter().map(|c| c.as_ref()));
                if !chain.is_empty() {
                    return chain;
                }
            }
            if let Some(ders) = any.downcast_ref::<Vec<Vec<u8>>>() {
                let chain = quinn_boring::peer_identity_from_ders(ders.iter().map(|c| c.as_slice()));
                if !chain.is_empty() {
                    return chain;
                }
            }
        }
        quinn_boring::peer_identity_from_der(fallback_pem_or_der)
    }

    async fn handle_resolver(
        resolver: ::h3::server::RequestResolver<::h3_quinn::Connection, Bytes>,
        live: Arc<LiveConfig>,
        lc: ListenerConfig,
        peer: SocketAddr,
    ) -> Result<()> {
        crate::server::qmux::stream_opened();
        let result = async {
            let (req, mut stream) = match resolver.resolve_request().await {
                Ok(pair) => pair,
                Err(e) => {
                    log::debug!("h3 resolve_request reset/cancel peer={peer}: {e:#}");
                    return Ok(());
                }
            };
            crate::server::telemetry::record_request();
            // P1-9：收齐 H3 请求体（上限 8MiB）——POST/PUT 才能把 body 交给引擎/admin；
            // 且不排空请求体会卡住 QUIC 流量控制。超限直接 413。
            let mut body: Vec<u8> = Vec::new();
            let mut overflow = false;
            loop {
                match stream.recv_data().await {
                    Ok(Some(mut buf)) => {
                        if body.len() + buf.remaining() > REQUEST_BODY_CAP {
                            overflow = true;
                            break;
                        }
                        let chunk = buf.copy_to_bytes(buf.remaining());
                        body.extend_from_slice(&chunk);
                    }
                    Ok(None) => break,
                    Err(e) => {
                        log::debug!("h3 recv_data peer={peer}: {e}");
                        return Ok(());
                    }
                }
            }
            if overflow {
                let resp = Response::builder()
                    .status(StatusCode::PAYLOAD_TOO_LARGE)
                    .body(())
                    .unwrap();
                let _ = stream.send_response(resp).await;
                return Ok(());
            }

            let method = req.method().as_str().to_string();
            let path = req.uri().path().to_string();
            let t0 = std::time::Instant::now();
            let req = req.map(|()| Bytes::from(body));
            let response = handle_h3(req, live.clone(), lc, peer).await;
            let (parts, body_out) = response.into_parts();
            let engine = parts
                .extensions
                .get::<crate::server::access_log::EngineTag>()
                .map(|t| t.0)
                .unwrap_or("http");
            // P1-11：完成侧全字段访问日志；h3 侧拿得到精确响应字节数。
            crate::server::access_log::log_response(
                &live,
                peer,
                "h3",
                &method,
                &path,
                parts.status.as_u16(),
                Some(body_out.len() as u64),
                t0.elapsed(),
                engine,
            );
            let resp = Response::from_parts(parts, ());
            if let Err(e) = stream.send_response(resp).await {
                log::debug!("h3 send_response peer={peer}: {e:#}");
                return Ok(());
            }
            if !body_out.is_empty() {
                if let Err(e) = stream.send_data(body_out).await {
                    log::debug!("h3 send_data peer={peer}: {e:#}");
                    return Ok(());
                }
            }
            if let Err(e) = stream.finish().await {
                log::debug!("h3 finish peer={peer}: {e:#}");
                return Ok(());
            }
            Ok(())
        }
        .await;
        crate::server::qmux::stream_closed();
        result
    }

    /// admin::handle 返回 `Response<BoxBody>`（h1 体类型）；h3 分支收齐为 `Response<Bytes>`。
    async fn collect_to_bytes(resp: Response<BoxBody>) -> Response<Bytes> {
        let (parts, body) = resp.into_parts();
        let data = BodyExt::collect(body)
            .await
            .map(|c| c.to_bytes())
            .unwrap_or_default();
        Response::from_parts(parts, data)
    }

    async fn handle_h3(
        req: Request<Bytes>,
        live: Arc<LiveConfig>,
        lc: ListenerConfig,
        peer: SocketAddr,
    ) -> Response<Bytes> {
        let mut req = req;
        let path = req.uri().path().to_string();

        let snap = live.snapshot();
        // Metrics / telemetry path
        if let Some(resp) = crate::server::telemetry::maybe_handle_simple(&req, &snap.telemetry)
        {
            return tag(resp, "telemetry");
        }
        if !crate::server::access::is_allowed(&snap.ip_access, peer) {
            return tag(
                Response::builder()
                    .status(StatusCode::FORBIDDEN)
                    .body(Bytes::from_static(b"forbidden by ip_access"))
                    .unwrap(),
                "acl",
            );
        }

        if let Some(rl) = &lc.rate_limit {
            if rl.enabled {
                let ok = if rl.per_path {
                    crate::server::rate_limit::allow_path(
                        peer.ip(),
                        &path,
                        rl.rate_per_sec,
                        rl.burst,
                    )
                } else {
                    crate::server::rate_limit::allow(peer.ip(), rl.rate_per_sec, rl.burst)
                };
                if !ok {
                    return tag(
                        Response::builder()
                            .status(StatusCode::TOO_MANY_REQUESTS)
                            .body(Bytes::from_static(b"rate limit exceeded"))
                            .unwrap(),
                        "acl",
                    );
                }
            }
        }

        // P0-1：listener 级 Basic Auth（§16.1）——与 h1/h2 对齐，堵住 h3 绕过。
        if let Some(ba) = &lc.basic_auth {
            if !crate::server::basic_auth::check_listener_headers(req.headers(), ba) {
                return tag(
                    Response::builder()
                        .status(StatusCode::UNAUTHORIZED)
                        .header(
                            http::header::WWW_AUTHENTICATE,
                            format!("Basic realm=\"{}\"", ba.realm),
                        )
                        .body(Bytes::from_static(b"unauthorized"))
                        .unwrap(),
                    "acl",
                );
            }
        }

        // P1-4：admin 走与 h1/h2 一致的完整 handle（旧实现只回 UI shell）。
        // 注：旧实现把 admin 放在 ip_access 之前，这里一并修正为规格顺序。
        if path.starts_with(&snap.admin.path) {
            let resp = crate::server::admin::handle(req.map(Full::new), live).await;
            let mut resp = collect_to_bytes(resp).await;
            resp.extensions_mut()
                .insert(crate::server::access_log::EngineTag("admin"));
            return resp;
        }

        // page_rules: block/redirect(apply_simple) + rewrite(路径改写) + cache/header(响应头)
        if let Some((status, location)) = crate::server::page_rules::apply_simple(&lc, &path) {
            if status == StatusCode::FORBIDDEN {
                return tag(
                    Response::builder()
                        .status(status)
                        .body(Bytes::from_static(b"blocked by page rule"))
                        .unwrap(),
                    "rule",
                );
            }
            return tag(
                Response::builder()
                    .status(status)
                    .header(http::header::LOCATION, location)
                    .body(Bytes::new())
                    .unwrap(),
                "rule",
            );
        }
        if let Some(np) = crate::server::page_rules::rewrite_path(&lc, &path) {
            let pq = match req.uri().query() {
                Some(q) => format!("{np}?{q}"),
                None => np,
            };
            if let Ok(u) = pq.parse() {
                *req.uri_mut() = u;
            }
        }
        // P1-5：h1 的 pass_upstream（page rule pass 动作）在 h3 同样生效。
        if let Some((murl, upstream)) = crate::server::page_rules::pass_upstream(&lc, &path) {
            let resp = crate::server::proxy::proxy_page_rule(
                req.map(Full::new),
                &murl,
                &upstream,
                peer.ip(),
                lc.ssl.is_some(),
            )
            .await;
            return tag(collect_to_bytes(resp).await, "proxy");
        }
        let resp_mods = crate::server::page_rules::response_headers(&lc, &path);
        let mut resp = h3_tail(req, live, lc, peer, &path).await;
        for (name, value) in resp_mods {
            if let (Ok(nn), Ok(vv)) = (
                name.parse::<http::header::HeaderName>(),
                http::header::HeaderValue::from_str(&value),
            ) {
                resp.headers_mut().insert(nn, vv);
            }
        }
        resp
    }

    async fn h3_tail(
        req: Request<Bytes>,
        live: Arc<LiveConfig>,
        lc: ListenerConfig,
        peer: SocketAddr,
        path: &str,
    ) -> Response<Bytes> {
        // P1-5：反代规则在 apps/static 之前（与 h1 dispatch_tail 对齐）。
        if would_proxy(&lc, path) {
            if let Some((_matched, resp)) =
                crate::server::proxy::try_proxy(&lc, req.map(Full::new), peer.ip()).await
            {
                return tag(collect_to_bytes(resp).await, "proxy");
            }
            return tag(
                Response::builder()
                    .status(StatusCode::BAD_GATEWAY)
                    .body(Bytes::from_static(b"proxy rule matched but produced no response"))
                    .unwrap(),
                "proxy",
            );
        }
        // Apps via try_handle_simple only when path/ext matches a listener app route.
        if apps::would_handle(&lc, path) {
            if let Some(bytes) = apps::try_handle_simple(&req, &live, &lc, peer).await {
                return tag_bytes(bytes);
            }
        }
        // Static files; metrics already handled above via telemetry::maybe_handle_simple.
        match static_files::serve_simple(&req, &lc).await {
            Ok(r) => tag(r, "static"),
            Err(_) => tag(
                Response::builder()
                    .status(StatusCode::NOT_FOUND)
                    .body(Bytes::from_static(b"not found"))
                    .unwrap(),
                "static",
            ),
        }
    }

    fn would_proxy(lc: &ListenerConfig, path: &str) -> bool {
        lc.proxy_rules.iter().any(|r| path.starts_with(&r.path))
    }

    fn tag(mut resp: Response<Bytes>, engine: &'static str) -> Response<Bytes> {
        resp.extensions_mut()
            .insert(crate::server::access_log::EngineTag(engine));
        resp
    }

    fn tag_bytes(resp: Response<Bytes>) -> Response<Bytes> {
        let mut resp = resp;
        resp.extensions_mut()
            .insert(crate::server::access_log::EngineTag("app"));
        resp
    }
}

#[cfg(feature = "tls")]
pub use imp::serve;

#[cfg(not(feature = "tls"))]
pub async fn serve(_bind: SocketAddr, _lc: ListenerConfig, _live: Arc<LiveConfig>) -> Result<()> {
    anyhow::bail!("HTTP/3 (QUIC) requires feature `tls`")
}
